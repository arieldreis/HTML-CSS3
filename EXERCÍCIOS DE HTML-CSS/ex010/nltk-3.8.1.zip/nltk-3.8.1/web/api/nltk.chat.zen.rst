nltk.chat.zen module
====================

.. automodule:: nltk.chat.zen
   :members:
   :undoc-members:
   :show-inheritance:
