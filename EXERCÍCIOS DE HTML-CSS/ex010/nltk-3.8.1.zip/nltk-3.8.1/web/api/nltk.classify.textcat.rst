nltk.classify.textcat module
============================

.. automodule:: nltk.classify.textcat
   :members:
   :undoc-members:
   :show-inheritance:
