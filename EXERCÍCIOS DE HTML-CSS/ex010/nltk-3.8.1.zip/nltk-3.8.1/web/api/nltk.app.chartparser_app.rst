nltk.app.chartparser\_app module
================================

.. automodule:: nltk.app.chartparser_app
   :members:
   :undoc-members:
   :show-inheritance:
