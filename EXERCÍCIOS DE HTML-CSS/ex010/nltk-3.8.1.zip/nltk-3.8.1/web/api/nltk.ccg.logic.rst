nltk.ccg.logic module
=====================

.. automodule:: nltk.ccg.logic
   :members:
   :undoc-members:
   :show-inheritance:
