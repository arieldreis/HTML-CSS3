nltk.classify.tadm module
=========================

.. automodule:: nltk.classify.tadm
   :members:
   :undoc-members:
   :show-inheritance:
