nltk.cluster.util module
========================

.. automodule:: nltk.cluster.util
   :members:
   :undoc-members:
   :show-inheritance:
