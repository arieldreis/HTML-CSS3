nltk.chunk package
==================

Submodules
----------

.. toctree::
   :maxdepth: 4

   nltk.chunk.api
   nltk.chunk.named_entity
   nltk.chunk.regexp
   nltk.chunk.util

Module contents
---------------

.. automodule:: nltk.chunk
   :members:
   :undoc-members:
   :show-inheritance:
