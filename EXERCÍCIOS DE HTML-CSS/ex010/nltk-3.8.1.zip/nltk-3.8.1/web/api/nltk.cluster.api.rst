nltk.cluster.api module
=======================

.. automodule:: nltk.cluster.api
   :members:
   :undoc-members:
   :show-inheritance:
