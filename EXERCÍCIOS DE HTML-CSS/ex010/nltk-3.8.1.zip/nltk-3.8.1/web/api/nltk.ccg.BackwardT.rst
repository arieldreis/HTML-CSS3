﻿nltk.ccg.BackwardT
==================

.. currentmodule:: nltk.ccg

.. autodata:: BackwardT