﻿nltk.ccg.ForwardApplication
===========================

.. currentmodule:: nltk.ccg

.. autodata:: ForwardApplication