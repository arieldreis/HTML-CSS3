nltk.app.chunkparser\_app module
================================

.. automodule:: nltk.app.chunkparser_app
   :members:
   :undoc-members:
   :show-inheritance:
