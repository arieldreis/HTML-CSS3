nltk.classify.weka module
=========================

.. automodule:: nltk.classify.weka
   :members:
   :undoc-members:
   :show-inheritance:
