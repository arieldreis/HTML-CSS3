﻿nltk.ccg.BackwardSx
===================

.. currentmodule:: nltk.ccg

.. autodata:: BackwardSx