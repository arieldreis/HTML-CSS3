nltk.ccg.api module
===================

.. automodule:: nltk.ccg.api
   :members:
   :undoc-members:
   :show-inheritance:
