﻿nltk.ccg.BackwardBx
===================

.. currentmodule:: nltk.ccg

.. autodata:: BackwardBx