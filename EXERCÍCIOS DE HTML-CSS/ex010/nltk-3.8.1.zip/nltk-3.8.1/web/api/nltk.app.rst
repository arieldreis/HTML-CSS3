nltk.app package
================

Submodules
----------

.. toctree::
   :maxdepth: 4

   nltk.app.chartparser_app
   nltk.app.chunkparser_app
   nltk.app.collocations_app
   nltk.app.concordance_app
   nltk.app.nemo_app
   nltk.app.rdparser_app
   nltk.app.srparser_app
   nltk.app.wordfreq_app
   nltk.app.wordnet_app

Module contents
---------------

.. automodule:: nltk.app
   :members:
   :undoc-members:
   :show-inheritance:
