nltk.app.wordnet\_app module
============================

.. automodule:: nltk.app.wordnet_app
   :members:
   :undoc-members:
   :show-inheritance:
