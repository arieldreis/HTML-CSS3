nltk.classify.naivebayes module
===============================

.. automodule:: nltk.classify.naivebayes
   :members:
   :undoc-members:
   :show-inheritance:
