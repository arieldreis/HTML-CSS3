nltk.classify.util module
=========================

.. automodule:: nltk.classify.util
   :members:
   :undoc-members:
   :show-inheritance:
