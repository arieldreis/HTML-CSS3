nltk.app.rdparser\_app module
=============================

.. automodule:: nltk.app.rdparser_app
   :members:
   :undoc-members:
   :show-inheritance:
