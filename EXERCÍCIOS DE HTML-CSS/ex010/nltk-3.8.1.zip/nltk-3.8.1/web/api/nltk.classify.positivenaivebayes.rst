nltk.classify.positivenaivebayes module
=======================================

.. automodule:: nltk.classify.positivenaivebayes
   :members:
   :undoc-members:
   :show-inheritance:
