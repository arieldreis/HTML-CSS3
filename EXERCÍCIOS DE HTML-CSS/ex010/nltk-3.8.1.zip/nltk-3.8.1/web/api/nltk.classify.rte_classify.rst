nltk.classify.rte\_classify module
==================================

.. automodule:: nltk.classify.rte_classify
   :members:
   :undoc-members:
   :show-inheritance:
