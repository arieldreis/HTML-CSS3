﻿nltk.ccg.BackwardComposition
============================

.. currentmodule:: nltk.ccg

.. autodata:: BackwardComposition