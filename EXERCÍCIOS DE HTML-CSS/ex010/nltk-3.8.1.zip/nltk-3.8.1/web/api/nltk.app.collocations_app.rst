nltk.app.collocations\_app module
=================================

.. automodule:: nltk.app.collocations_app
   :members:
   :undoc-members:
   :show-inheritance:
