﻿nltk.ccg.ForwardSubstitution
============================

.. currentmodule:: nltk.ccg

.. autodata:: ForwardSubstitution