nltk.book module
================

.. automodule:: nltk.book
   :members:
   :undoc-members:
   :show-inheritance:
