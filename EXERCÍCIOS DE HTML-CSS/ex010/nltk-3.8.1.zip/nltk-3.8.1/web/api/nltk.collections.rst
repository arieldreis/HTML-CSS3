nltk.collections module
=======================

.. automodule:: nltk.collections
   :members:
   :undoc-members:
   :show-inheritance:
