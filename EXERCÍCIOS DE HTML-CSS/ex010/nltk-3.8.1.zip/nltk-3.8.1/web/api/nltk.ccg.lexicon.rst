nltk.ccg.lexicon module
=======================

.. automodule:: nltk.ccg.lexicon
   :members:
   :undoc-members:
   :show-inheritance:
