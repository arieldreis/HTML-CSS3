nltk.classify.scikitlearn module
================================

.. automodule:: nltk.classify.scikitlearn
   :members:
   :undoc-members:
   :show-inheritance:
