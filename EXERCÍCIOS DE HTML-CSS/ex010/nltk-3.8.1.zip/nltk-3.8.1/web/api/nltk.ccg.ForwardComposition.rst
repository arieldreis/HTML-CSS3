﻿nltk.ccg.ForwardComposition
===========================

.. currentmodule:: nltk.ccg

.. autodata:: ForwardComposition