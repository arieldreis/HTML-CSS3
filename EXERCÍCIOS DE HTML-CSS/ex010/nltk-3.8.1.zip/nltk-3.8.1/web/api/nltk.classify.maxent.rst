nltk.classify.maxent module
===========================

.. automodule:: nltk.classify.maxent
   :members:
   :undoc-members:
   :show-inheritance:
