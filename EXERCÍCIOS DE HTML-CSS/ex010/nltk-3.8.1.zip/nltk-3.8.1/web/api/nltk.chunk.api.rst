nltk.chunk.api module
=====================

.. automodule:: nltk.chunk.api
   :members:
   :undoc-members:
   :show-inheritance:
