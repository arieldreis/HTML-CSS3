nltk.chat.util module
=====================

.. automodule:: nltk.chat.util
   :members:
   :undoc-members:
   :show-inheritance:
