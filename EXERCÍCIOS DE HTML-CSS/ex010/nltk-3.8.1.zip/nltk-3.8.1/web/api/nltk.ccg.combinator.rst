nltk.ccg.combinator module
==========================

.. automodule:: nltk.ccg.combinator
   :members:
   :undoc-members:
   :show-inheritance:
