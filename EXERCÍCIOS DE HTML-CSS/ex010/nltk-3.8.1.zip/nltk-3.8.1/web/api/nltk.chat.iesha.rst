nltk.chat.iesha module
======================

.. automodule:: nltk.chat.iesha
   :members:
   :undoc-members:
   :show-inheritance:
