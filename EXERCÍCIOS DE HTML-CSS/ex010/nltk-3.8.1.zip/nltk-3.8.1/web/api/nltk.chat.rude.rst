nltk.chat.rude module
=====================

.. automodule:: nltk.chat.rude
   :members:
   :undoc-members:
   :show-inheritance:
