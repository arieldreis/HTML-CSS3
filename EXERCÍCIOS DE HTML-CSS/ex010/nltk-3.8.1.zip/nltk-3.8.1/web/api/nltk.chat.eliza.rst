nltk.chat.eliza module
======================

.. automodule:: nltk.chat.eliza
   :members:
   :undoc-members:
   :show-inheritance:
