﻿nltk.ccg.BackwardApplication
============================

.. currentmodule:: nltk.ccg

.. autodata:: BackwardApplication