﻿nltk.ccg.ForwardT
=================

.. currentmodule:: nltk.ccg

.. autodata:: ForwardT